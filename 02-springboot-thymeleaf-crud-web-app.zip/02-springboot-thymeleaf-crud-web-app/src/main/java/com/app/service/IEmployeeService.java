package com.app.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.app.model.Employee;

public interface IEmployeeService {
	List<Employee> getAllEmployees();
	String createEmployee(Employee employee);
	Employee getEmployeeById(String id);
	String deleteEmployeeById(String id);
	Page<Employee> getAllEmployeesWithPagination(Integer pageNo, Integer pageSize);
	
	
}
