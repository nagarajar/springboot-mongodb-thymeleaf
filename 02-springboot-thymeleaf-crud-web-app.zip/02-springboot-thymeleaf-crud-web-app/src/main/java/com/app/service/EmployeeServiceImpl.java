package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.app.model.Employee;
import com.app.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private EmployeeRepository repo;
	
	@Override
	public List<Employee> getAllEmployees() {
		return repo.findAll();
	}

	@Override
	public String createEmployee(Employee employee) {
		employee = repo.save(employee);
		return "Employee ID = '"+ employee.getId() +"' Record Created Successfully...!";
	}

	@Override
	public Employee getEmployeeById(String id) {
		Optional<Employee> findById = repo.findById(id);
		Employee employee = null;
		if(findById.isPresent()) {
			employee = findById.get();
		}
		else {
			throw new RuntimeException("Employee ID='"+id+" Not Found");
		}
		return employee;
	}

	@Override
	public String deleteEmployeeById(String id) {
		if(repo.existsById(id)) {
			repo.deleteById(id);
			return "Employee ID = '"+id+"' Record Deleted Successfully...!";	
		}
		else {
			throw new RuntimeException("Employee ID='"+id+" Not Found");
		}
	}

	@Override
	public Page<Employee> getAllEmployeesWithPagination(Integer pageNo, Integer pageSize) {
		Pageable pageable = PageRequest.of(pageNo-1, pageSize);
		return repo.findAll(pageable);
	}


}
