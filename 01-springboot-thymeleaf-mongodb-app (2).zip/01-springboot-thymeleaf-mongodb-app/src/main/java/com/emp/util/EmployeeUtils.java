package com.emp.util;

import java.util.Arrays;
import java.util.List;

import org.springframework.ui.Model;

public interface EmployeeUtils {
	public static void createDeptList(Model model) {
		List<String> list = Arrays.asList("DEV","QA","UAT","SIT","BA");
		model.addAttribute("deptList", list);
	}
}
