package com.emp.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.emp.entity.Employee;

public interface IEmployeeService {
	List<Employee> getAllEmployees();
	String createEmployee(Employee employee);
	String updateEmployee(Employee employee,String id);
	Employee getEmployeeById(String id);
	String deleteEmployeeById(String id);
	Page<Employee> getAllEmployeesWithPagination(Integer pageNo, Integer pageSize);
	
}
