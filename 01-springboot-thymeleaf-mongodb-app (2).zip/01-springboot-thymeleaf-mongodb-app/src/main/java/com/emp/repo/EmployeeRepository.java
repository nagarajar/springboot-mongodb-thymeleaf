package com.emp.repo;

import java.io.Serializable;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.emp.entity.Employee;

public interface EmployeeRepository extends MongoRepository<Employee, Serializable> {

}
