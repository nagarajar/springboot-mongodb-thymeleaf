package com.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.emp.entity.Employee;
import com.emp.service.IEmployeeService;
import com.emp.util.EmployeeUtils;

@Controller
public class EmployeeController {
	
	@Autowired
	IEmployeeService  service;
	
	// 1. Display Employee List
	@GetMapping("/")
	public String viewHomePage(Model model) {
		/*
		 * model.addAttribute("employeesList", service.getAllEmployees()); return
		 * "index";
		 */
		// After adding pagination
		
		return getPaginatedView(1, model);
	}
	
	@GetMapping("/showNewEmployeeFrom")
	public String showNewEmployeeForm(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		EmployeeUtils.createDeptList(model);
		return "new_employee";
	}
	
	@PostMapping("/createEmployee")
	public String createEmployee(@ModelAttribute("employee") Employee employee, Model model) {
		String msg = service.createEmployee(employee);
		model.addAttribute("msg", msg);
		return "redirect:/";
	}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable String id, Model model) {
		Employee employee = service.getEmployeeById(id);
		model.addAttribute("employee", employee);
		EmployeeUtils.createDeptList(model);
		return "update_employee";
	}
	
	@GetMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable String id, Model model) {
		String msg = service.deleteEmployeeById(id);
		model.addAttribute("msg", msg);
		return "redirect:/";
	}
	
	@PostMapping("/updateEmployee/{id}")
	public String updateEmployee(@ModelAttribute("employee") Employee employee, Model model, @PathVariable String id) {
		String msg = service.updateEmployee(employee, id);
		model.addAttribute("msg", msg);
		return "redirect:/";
	}
	
	@GetMapping("/page/{pageNo}")
	public String getPaginatedView(@PathVariable Integer pageNo, Model model) {
		Integer pageSize = 10;

		Page<Employee> page = service.getAllEmployeesWithPagination(pageNo, pageSize);
		List<Employee> employeesList = page.getContent();

		model.addAttribute("currentPage", pageNo);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("employeesList", employeesList);
		return "index";
	}
}
